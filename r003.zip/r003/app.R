# Load necessary libraries
library(shiny)
library(plotly)
library(dplyr)

# Load the stock data
stock_data <- read.csv("TSLA.csv")

# Convert Date column to Date type
stock_data$Date <- as.Date(stock_data$Date)

# Define UI for the app
ui <- fluidPage(
  titlePanel("Tesla Stock Analysis Tool"),
  
  sidebarLayout(
    sidebarPanel(
      sliderInput("dateRange", "Select Date Range:",
                  min = min(stock_data$Date),
                  max = max(stock_data$Date),
                  value = c(min(stock_data$Date), max(stock_data$Date))),
      
      checkboxGroupInput("metrics", "Select Metrics for Regression:",
                         choices = c("Open", "High", "Low", "Close", "Volume"),
                         selected = c("Open", "Close")),
      
      actionButton("submit", "Submit")
    ),
    
    mainPanel(
      tabsetPanel(
        tabPanel("Data View", tableOutput("dataTable")),
        tabPanel("Regression Analysis", plotlyOutput("regressionPlot"))
      )
    )
  )
)

# Define server logic for the app
server <- function(input, output) {
  
  # Reactive expression to filter data based on date range
  filtered_data <- reactive({
    req(input$dateRange)
    stock_data %>%
      filter(Date >= input$dateRange[1] & Date <= input$dateRange[2])
  })
  
  # Output the filtered data table
  output$dataTable <- renderTable({
    filtered_data()
  })
  
  # Perform regression analysis and create plot
  output$regressionPlot <- renderPlotly({
    req(input$submit)
    
    # Get the selected metrics
    metrics <- input$metrics
    
    # Ensure at least two metrics are selected
    if (length(metrics) < 2) {
      return(NULL)
    }
    
    # Perform regression analysis
    formula <- as.formula(paste(metrics[2], "~", metrics[1]))
    model <- lm(formula, data = filtered_data())
    
    # Create the plot
    plot_data <- filtered_data()
    plot <- plot_ly(plot_data, x = ~get(metrics[1]), y = ~get(metrics[2]), type = 'scatter', mode = 'markers') %>%
      add_lines(x = ~get(metrics[1]), y = fitted(model), name = 'Fitted Line') %>%
      layout(title = paste("Regression Analysis:", metrics[2], "vs", metrics[1]),
             xaxis = list(title = metrics[1]),
             yaxis = list(title = metrics[2]))
    
    plot
  })
}

# Run the application 
shinyApp(ui = ui, server = server)